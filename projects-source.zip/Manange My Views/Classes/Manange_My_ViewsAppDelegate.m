//
//  Manange_My_ViewsAppDelegate.m
//  Manange My Views
//
//  Created by sk on 1/17/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "Manange_My_ViewsAppDelegate.h"
#import "Manange_My_ViewsViewController.h"

@implementation Manange_My_ViewsAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
