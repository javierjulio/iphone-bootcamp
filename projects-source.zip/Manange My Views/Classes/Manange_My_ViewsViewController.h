//
//  Manange_My_ViewsViewController.h
//  Manange My Views
//
//  Created by sk on 1/17/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Manange_My_ViewsViewController : UIViewController <UIActionSheetDelegate> { 
    UILabel *countLabel;
    NSString *mString;
    NSMutableString *mMutableString;
    NSMutableArray *mIvarStorage;
}

@property (nonatomic, retain) IBOutlet UILabel *countLabel;
@property (nonatomic, retain) NSString *mString;
@property (nonatomic, retain) NSMutableString *mMutableString;
@property (nonatomic, retain) NSMutableArray *mIvarStorage;

- (IBAction) retainButtonPressed;
- (IBAction) releaseButtonPressed;
- (void) updateLabel:(NSUInteger)count;
@end

