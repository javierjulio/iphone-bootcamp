//
//  Manange_My_ViewsAppDelegate.h
//  Manange My Views
//
//  Created by sk on 1/17/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Manange_My_ViewsViewController;

@interface Manange_My_ViewsAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    Manange_My_ViewsViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Manange_My_ViewsViewController *viewController;

@end

