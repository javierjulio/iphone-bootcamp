//
//  Hello_WorldAppDelegate.m
//  Hello World
//
//  Created by sk on 1/4/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "Hello_WorldAppDelegate.h"
#import "Hello_WorldViewController.h"

@implementation Hello_WorldAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"My Alert" 
                                                    message:@"Danger! Danger!" 
                                                   delegate:self 
                                          cancelButtonTitle:@"Cancel?" 
                                          otherButtonTitles:nil];

    [alert show];
    [alert release];    

    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}



- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
