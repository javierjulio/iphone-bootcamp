//
//  Hello_WorldViewController.h
//  Hello World
//
//  Created by sk on 1/4/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Hello_WorldViewController : UIViewController {

}

@end

