//
//  Exercise_19__Web_Service_ViewController.h
//  Exercise-19 (Web Service)
//
//  Created by sk on 2/13/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListParser.h"

@interface Exercise_19__Web_Service_ViewController : UIViewController {
    UITextView *mTextView;
    NSMutableData *mReceivedData;
}

@property (nonatomic, retain) IBOutlet UITextView *mTextView;
@property (nonatomic, retain) NSMutableData *mReceivedData;

- (IBAction) getButton;

@end

