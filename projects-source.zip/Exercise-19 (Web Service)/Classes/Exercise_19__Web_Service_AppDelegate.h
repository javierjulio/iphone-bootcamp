//
//  Exercise_19__Web_Service_AppDelegate.h
//  Exercise-19 (Web Service)
//
//  Created by sk on 2/13/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Exercise_19__Web_Service_ViewController;

@interface Exercise_19__Web_Service_AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    Exercise_19__Web_Service_ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Exercise_19__Web_Service_ViewController *viewController;

@end

