//
//  CoreLocationViewController.h
//  Tab
//
//  Created by sk on 1/26/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface CoreLocationViewController : UIViewController <CLLocationManagerDelegate> {
    CLLocationManager *mLocationManager;
    CLLocation *mStartDistance;
    
    UILabel *mLat, *mLong, *mAlt, *mVertAcc, *mHorzAcc;
}

@property (nonatomic, retain) IBOutlet UILabel *mLat, *mLong, *mAlt, *mVertAcc, *mHorzAcc;
@property (nonatomic, retain) CLLocation *mStartDistance;
@property (nonatomic, retain) CLLocationManager *mLocationManager;

@end
