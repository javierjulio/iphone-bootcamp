#import <Foundation/Foundation.h>

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    
    // Create an array of 2 elements
    NSMutableArray *array1 = [[NSMutableArray alloc] initWithObjects:@"first", @"second", @"third", nil];
    

    // Oh, forgot, gotta remove that last entry!
    [array1 removeLastObject];
    
    // Get the length of the array
    int arrayLength = [array1 count];
        
    // Iterate through the array, NSLog'ing the value of each element
    for (int c=0; c<arrayLength; ++c)
    {
        NSLog(@"array1[%d] = %@", c, [array1 objectAtIndex:c]);
    }
    
    // Display the object at index 1
    NSLog(@"array1[1] = %@", [array1 objectAtIndex:1]);

    // We're done, let em go
    [array1 release];
    
    [pool drain];
    return 0;
}
