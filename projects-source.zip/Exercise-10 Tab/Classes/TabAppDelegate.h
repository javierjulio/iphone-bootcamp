//
//  TabAppDelegate.h
//  Tab
//
//  Created by sk on 1/26/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    UITabBarController *rootController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UITabBarController *rootController;

@end

