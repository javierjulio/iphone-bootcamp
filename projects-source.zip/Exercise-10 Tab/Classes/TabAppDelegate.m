//
//  TabAppDelegate.m
//  Tab
//
//  Created by sk on 1/26/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "TabAppDelegate.h"

@implementation TabAppDelegate

@synthesize window;
@synthesize rootController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window addSubview:rootController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [rootController release];
    [window release];
    [super dealloc];
}

@end
