//
//  Hi_My_Name_IsAppDelegate.h
//  Hi My Name Is
//
//  Created by sk on 1/6/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Hi_My_Name_IsViewController;

@interface Hi_My_Name_IsAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    Hi_My_Name_IsViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Hi_My_Name_IsViewController *viewController;

@end

