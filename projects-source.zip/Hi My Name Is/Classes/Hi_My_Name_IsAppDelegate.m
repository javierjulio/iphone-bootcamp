//
//  Hi_My_Name_IsAppDelegate.m
//  Hi My Name Is
//
//  Created by sk on 1/6/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "Hi_My_Name_IsAppDelegate.h"
#import "Hi_My_Name_IsViewController.h"
#import "Register.h"

@implementation Hi_My_Name_IsAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    Register *object1 = [[Register alloc] init];
    [object1 printName];
    [object1 release];
    
    Register *object2 = [[Register alloc] initWithName:@"Ben"];
    [object2 printName];
    [object2 release];
        
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}

- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}

@end
