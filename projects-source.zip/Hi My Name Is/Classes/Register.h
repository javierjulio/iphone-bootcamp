//
//  Register.h
//  Hi My Name Is
//
//  Created by sk on 1/6/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Register : NSObject {
    NSString *mName;
}

- (id) initWithName:(NSString *) name;
- (NSUInteger) getCharacterCount:(NSString *) name;
- (void) printName;

@end
