//
//  Register.m
//  Hi My Name Is
//
//  Created by sk on 1/6/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import "Register.h"


@implementation Register

- (id) initWithName:(NSString *)name
{
    if (self == [super init])
    {
        mName = name;
    }
    return self;
}

- (NSUInteger) getCharacterCount:(NSString *) name
{
    return [name length];
}

- (void) printName
{
    NSLog(@"Name = %@", mName);
}

- (void) dealloc
{
    [mName release];
    [super dealloc];
}

@end
