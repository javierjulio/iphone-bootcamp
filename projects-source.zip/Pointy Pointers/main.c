#include <stdio.h>

int main (int argc, const char * argv[]) {

    int *foo_ptr;
    int foo1 = 0;

    foo_ptr =& foo1;

    for (int i=0; i < 10; ++i)
    {
        (*foo_ptr)++;
    }
    
    printf("foo1 = %d", foo1);
}
