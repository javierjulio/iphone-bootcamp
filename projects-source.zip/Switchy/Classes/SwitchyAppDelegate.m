//
//  SwitchyAppDelegate.m
//  Switchy
//
//  Created by sk on 1/24/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "SwitchyAppDelegate.h"
#import "SwitchViewController.h"

@implementation SwitchyAppDelegate

@synthesize window;
@synthesize switchViewController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window addSubview:switchViewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [switchViewController release];
    [super dealloc];
}


@end
