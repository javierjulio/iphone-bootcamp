//
//  SwitchViewController.h
//  Switchy
//
//  Created by sk on 1/24/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BadNewsViewController;
@class GoodNewsViewController;

@interface SwitchViewController : UIViewController {
    BadNewsViewController *mBadNewsViewController;
    GoodNewsViewController *mGoodNewsViewController;
}

@property (nonatomic, retain) BadNewsViewController *mBadNewsViewController;
@property (nonatomic, retain) GoodNewsViewController *mGoodNewsViewController;

- (IBAction) switchview:(id)sender;

@end
