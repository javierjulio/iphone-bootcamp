//
//  CustomCell.h
//  Table
//
//  Created by sk on 2/7/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomCell : UITableViewCell {
    UILabel *mName;
}

@property (nonatomic, retain) IBOutlet UILabel *mName;

@end
