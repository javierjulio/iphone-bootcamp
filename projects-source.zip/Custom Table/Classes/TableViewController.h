//
//  TableViewController.h
//  Table
//
//  Created by sk on 2/6/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
    NSArray *mList;
}
@property (nonatomic, retain) NSArray *mList;

@end

