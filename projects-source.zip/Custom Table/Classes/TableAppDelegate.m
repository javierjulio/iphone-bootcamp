//
//  TableAppDelegate.m
//  Table
//
//  Created by sk on 2/6/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "TableAppDelegate.h"
#import "TableViewController.h"

@implementation TableAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
