//
//  TableViewController.m
//  Table
//
//  Created by sk on 2/6/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "TableViewController.h"
#import "CustomCell.h"

@implementation TableViewController
@synthesize mList;


/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


///*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    self.mList = [[NSArray alloc] initWithObjects:@"Windows 3.11", @"Windows 95", @"Windows 98", @"Windows ME",
             @"Windows NT", @"Windows 2000", @"Windows XP", @"Windows Vista", @"Windows 7", nil];
    
    [super viewDidLoad];
}
//*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

#pragma mark - 
#pragma mark Table View Data Source Methods


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [mList count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *) indexPath
{
    CustomCell *cell = [[[CustomCell alloc] init] autorelease]; 

    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
    cell = [nib objectAtIndex:0];
    cell.mName.text = [mList objectAtIndex:[indexPath row]];
    return cell;
}

- (CGFloat)tableView:(UITableView *) tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

#pragma mark

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    mList = nil;
    [super viewDidUnload];
}


- (void)dealloc {
    [mList release];
    [super dealloc];
}

@end
