//
//  FirstLevelViewController.m
//  Exercise-15 Navigator
//
//  Created by sk on 2/8/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import "FirstLevelViewController.h"
#import "SecondLevelViewController.h" 
#import "MoveItController.h"
#import "TouchyViewController.h"
#import "SwipeyViewController.h"
#import "PinchyViewController.h"

@implementation FirstLevelViewController
@synthesize mControllers;

- (void)viewDidLoad
{
    self.title = @"First Level";
    self.mControllers = [[NSMutableArray alloc] init];
    
    // Move it
    MoveItController *moveController = [[MoveItController alloc] initWithStyle:UITableViewStylePlain];
    moveController.title = @"Move IT!";
    [mControllers addObject:moveController];
    [moveController release];
    
    // Touchy
    TouchyViewController *touchController = [[TouchyViewController alloc] init];
    touchController.title = @"Touch it!";
    [mControllers addObject:touchController];
    [touchController release];
    
    // Swipey
    SwipeyViewController *swipeController = [[SwipeyViewController alloc] init];
    swipeController.title = @"Swipe it!";
    [mControllers addObject:swipeController];
    [swipeController release];
    
    // Pinchy
    PinchyViewController *pinchController = [[PinchyViewController alloc] init];
    pinchController.title = @"Pinch it!";
    [mControllers addObject:pinchController];
    [pinchController release];
    
    [super viewDidLoad];
}

-(void)viewDidUnload
{
    mControllers = nil;
    [super viewDidUnload];
}

-(void) dealloc
{
    [mControllers release];
    [super dealloc];
}


// Table datasource methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [mControllers count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView 
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *firstLevelCellId = @"firstLevelCellId";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:firstLevelCellId];
    
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:firstLevelCellId] 
                autorelease];
    }

    SecondLevelViewController *controller = [mControllers objectAtIndex:[indexPath row]];
    cell.textLabel.text = controller.title;
    
    return cell;
}

// Table View delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SecondLevelViewController *nextController = [mControllers objectAtIndex:[indexPath row]];
    [self.navigationController pushViewController:nextController animated:YES];
}

@end
