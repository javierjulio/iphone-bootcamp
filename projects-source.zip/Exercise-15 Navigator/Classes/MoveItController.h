//
//  MoveItController.h
//  Exercise-15 Navigator
//
//  Created by sk on 2/8/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondLevelViewController.h"


@interface MoveItController : SecondLevelViewController {
    NSMutableArray *mList;
}

@property (nonatomic, retain) NSMutableArray *mList;
-(IBAction) moveButton;

@end
