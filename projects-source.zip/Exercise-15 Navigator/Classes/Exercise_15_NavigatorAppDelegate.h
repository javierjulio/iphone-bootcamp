//
//  Exercise_15_NavigatorAppDelegate.h
//  Exercise-15 Navigator
//
//  Created by sk on 2/8/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Exercise_15_NavigatorAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    UINavigationController *mNavigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *mNavigationController;

@end

