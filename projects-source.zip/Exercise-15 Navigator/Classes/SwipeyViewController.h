//
//  SwipeyViewController.h
//  Exercise-15 Navigator
//
//  Created by sk on 2/10/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>

#define MIN_GESTURE_LENGTH 25
#define MAX_VARIANCE        5

@interface SwipeyViewController : UIViewController {
    UILabel *mLabel;
    CGPoint mGestureStartPoint;
}

@property (nonatomic, retain) IBOutlet UILabel *mLabel;
@property CGPoint mGestureStartPoint;

- (void) erase;

@end
