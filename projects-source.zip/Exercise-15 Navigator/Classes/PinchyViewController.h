//
//  PinchyViewController.h
//  Exercise-15 Navigator
//
//  Created by sk on 2/12/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>

#define MINIMUM_PINCH 100

@interface PinchyViewController : UIViewController {
    UILabel *mLabel;
    CGFloat mDistance;
}

@property (nonatomic, retain) IBOutlet UILabel *mLabel;
@property CGFloat mDistance;

- (void) erase;
- (CGFloat)distanceBetweenTwoPoints:(CGPoint)fromPoint toPoint:(CGPoint)toPoint;

@end
