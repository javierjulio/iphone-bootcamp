//
//  SecondLevelViewController.h
//  Exercise-15 Navigator
//
//  Created by sk on 2/8/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SecondLevelViewController : UITableViewController {

}

@end
