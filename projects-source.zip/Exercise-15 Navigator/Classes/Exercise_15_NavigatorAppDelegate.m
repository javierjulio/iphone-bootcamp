//
//  Exercise_15_NavigatorAppDelegate.m
//  Exercise-15 Navigator
//
//  Created by sk on 2/8/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "Exercise_15_NavigatorAppDelegate.h"

@implementation Exercise_15_NavigatorAppDelegate

@synthesize window;
@synthesize mNavigationController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window addSubview: mNavigationController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [mNavigationController release];
    [super dealloc];
}


@end
