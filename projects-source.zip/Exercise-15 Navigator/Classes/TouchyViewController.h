//
//  TouchyViewController.h
//  Exercise-15 Navigator
//
//  Created by sk on 2/10/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TouchyViewController : UIViewController {
    UILabel *mMessageLabel;
    UILabel *mTapLabel;
    UILabel *mTouchLabel;
}

@property (nonatomic, retain) IBOutlet UILabel *mMessageLabel, *mTapLabel, *mTouchLabel;

- (void) updateLabelsFromTouch:(NSSet *)touches;

@end
