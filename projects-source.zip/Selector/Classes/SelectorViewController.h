//
//  SelectorViewController.h
//  Selector
//
//  Created by sk on 5/5/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectorViewController : UIViewController {
    int mCount;
}

- (void) doSomething;

@end

