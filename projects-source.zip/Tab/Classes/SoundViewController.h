//
//  SoundViewController.h
//  Tab
//
//  Created by sk on 1/26/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SoundViewController : UIViewController {

}

@end
