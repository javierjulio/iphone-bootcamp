//
//  good.h
//  Own My Own
//
//  Created by sk on 1/25/10.
//  Copyright 2010 Ben Sgro aka Mr-sk. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface good : UIViewController {

}

@end
