//
//  Own_My_OwnViewController.m
//  Own My Own
//
//  Created by sk on 1/25/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "Own_My_OwnViewController.h"
#import "bad.h"
#import "good.h"

@implementation Own_My_OwnViewController
@synthesize mGoodController;
@synthesize mBadController;


/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

///*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)viewDidLoad {

    good *goodController = [[good alloc] initWithNibName:@"good" bundle:nil];
    self.mGoodController = goodController;
    [self.view insertSubview:self.mGoodController.view atIndex:0];
    [goodController release];
    [super viewDidLoad];
}
//*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (IBAction) switch
{
    NSLog(@"switch");
    bad *badController = [[bad alloc] initWithNibName:@"bad" bundle:nil];
    self.mBadController = badController;
    [badController release];
    
    [self.mGoodController.view removeFromSuperview];
    [self.view insertSubview:self.mBadController.view atIndex:0];
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
