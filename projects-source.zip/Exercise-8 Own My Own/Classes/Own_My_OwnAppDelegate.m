//
//  Own_My_OwnAppDelegate.m
//  Own My Own
//
//  Created by sk on 1/25/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import "Own_My_OwnAppDelegate.h"
#import "Own_My_OwnViewController.h"

@implementation Own_My_OwnAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
