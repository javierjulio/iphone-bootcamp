//
//  Own_My_OwnViewController.h
//  Own My Own
//
//  Created by sk on 1/25/10.
//  Copyright Ben Sgro aka Mr-sk 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class bad;
@class good;

@interface Own_My_OwnViewController : UIViewController {
    bad *mBadController;
    good *mGoodController;
}

@property(nonatomic, retain) bad *mBadController;
@property(nonatomic, retain) good *mGoodController;
- (IBAction) switch;

@end

